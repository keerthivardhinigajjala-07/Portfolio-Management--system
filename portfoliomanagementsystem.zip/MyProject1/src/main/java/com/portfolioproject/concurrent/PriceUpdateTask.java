//package com.portfolioproject.concurrent;
//
//public class PriceUpdateTask implements Runnable 
//{
//
//    private String stockSymbol;
//    public PriceUpdateTask(String stockSymbol)
//    {
//        this.stockSymbol = stockSymbol;
//    }
//@Override
//    public void run() 
//    {
//        System.out.println("Updating price for " + stockSymbol +
//                " - Thread: " +Thread.currentThread().getName());
//
//        System.out.println("Price updated for " + stockSymbol +
//                " - Thread: " +Thread.currentThread().getName());
//    }
//}
// Using Runnable with stock id
//package com.portfolioproject.concurrent;
//
//import com.portfolioproject.model.Stock;
//public class PriceUpdateTask implements Runnable 
//{
//    private Stock stock;
//    public PriceUpdateTask(Stock stock) 
//    {
//        this.stock = stock;
//    }
//    @Override
//    public void run() 
//    {
//        System.out.println("Updating Stock: "+stock.getAssetName() +
//                " - Thread: " +Thread.currentThread().getName());
//        double oldPrice = stock.getCurrentPrice();
//        double newPrice = oldPrice + 10;
//        stock.setCurrentPrice(newPrice);
//        System.out.println("Old Price: " + oldPrice);
//        System.out.println("New Price: " + newPrice);
//        System.out.println("Stock update completed for " +stock.getAssetName());
//    }
//}
// using Callable with future 
package com.portfolioproject.concurrent;
import java.util.concurrent.Callable;
import com.portfolioproject.model.Stock;

public class PriceUpdateTask implements Callable<Double> 
{
    private Stock stock;
    public PriceUpdateTask(Stock stock)
    {
        this.stock = stock;
    }
    @Override
    public Double call()
{
        double oldPrice = stock.getCurrentPrice();
        System.out.println("Updating Stock: " + stock.getAssetName()
                + " - Thread: " + Thread.currentThread().getName());
        double newPrice = oldPrice + 10;
        stock.setCurrentPrice(newPrice);
        System.out.println("Old Price: " + oldPrice);
        System.out.println("New Price: " + newPrice);
        System.out.println("Stock update completed for "+ stock.getAssetName());
        return newPrice;
    }
}
